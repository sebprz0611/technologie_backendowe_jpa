package com.jpacourse.persistence.dao;

import com.jpacourse.persistence.entity.AddressEntity;

public interface AddressDao extends Dao<AddressEntity, Long>
{

}
