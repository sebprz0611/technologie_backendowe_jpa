package com.jpacourse.persistence.dao;

import com.jpacourse.persistence.entity.DoctorEntity;

public interface DoctorDao extends Dao<DoctorEntity, Long>
{
}
