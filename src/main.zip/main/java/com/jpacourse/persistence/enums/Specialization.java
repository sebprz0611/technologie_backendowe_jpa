package com.jpacourse.persistence.enums;

public enum Specialization {
	Urologia,
	Kardiochirurgia,
	Pediatria,
	Neurologia,
	Onkologia,
	Ortopedia,
	Stomatologia,
	Chirurgia,
	Psychiatra,
	Dermatologia
}
