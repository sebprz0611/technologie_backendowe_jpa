package com.jpacourse.persistence.enums;

public enum TreatmentType {
	Badanie,
	Operacja,
	Opieka_medyczna,
	Konsultacja,
	Rehabilitacja
}
